var mongoose= require("mongoose");
var cadenaConexion="mongodb://localhost/DBDummy"
var Schema= mongoose.Schema;

mongoose.connect(cadenaConexion,{},(err,res)=>{
    if(err){
        console.log("Ocurrio un error");
    }else{
        console.log("Se conecto correctamente");
    }
})

var objeto=new Schema({
    _id: Schema.Types.String,
    nombre:Schema.Types.String,
    cantidad:Schema.Types.String,
    precio:Schema.Types.Number,
    vencimiento:Schema.Types.Date,
    ven:Schema.Types.String
},{collection:"Productos"})

var Productos=mongoose.model("Productos",objeto);

class ProductoController{

    getAll(request,response){
        Productos.aggregate([
            {
                $project:{
                    _id:1,nombre:1,cantidad:1,precio:1,
                    ven:{$dateToString:{format:"%d-%m-%Y", date:"$vencimiento"}}
                }
            }
        ]).then(res=>{
            response.json(res)
        }).catch(err=>{
            response.end("Ocurrio un error");
        })
    }
}

module.exports= new ProductoController();