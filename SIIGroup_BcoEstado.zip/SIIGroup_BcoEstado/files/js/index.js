window.onload=function(){
    listar();
}

function listar(){
    fetch("/listarProductos").then(res=>{
        res.json().then(json=>{
            //alert(JSON.stringify(json));
            listarProductos(json);
        })
    })
}

function listarProductos(res){
    `string text` //Template String, permite agregar saltos de linea
    var contenido=`
    
     <table class="table">
        <thead>
            <tr>
                <th>Id Producto</th>
                <th>Nombre</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Fecha Vencimiento</th>
                
            </tr>
        </thead>

    `;
    contenido+="<tbody>";
    for(var i=0; i<res.length;i++){
        data=res[i];
        contenido+=`
            <tr>
                <td>${data._id}</td>
                <td>${data.nombre}</td>
                <td>${data.cantidad}</td>
                <td>${data.precio}</td>
                <td>${data.ven}</td>
                
            </tr>
        
        `
    }

    contenido+="</tbody>";

    contenido+="</table>";
    document.getElementById("divProducto").innerHTML=contenido;

}