var express= require("express");
const { request } = require("http");
var app=express();
//Modulo path
var path=require("path");

//Le decimos al servidor que existe bootstrap
app.use("/css",express.static("./node_modules/bootstrap/dist/css"));
app.use("/files",express.static(path.join(__dirname,"files")));

//Se Recibe el archivo conexion.js
var cn= require("./dummy/conexion");

//Indica que pagina saldra al iniciar
app.get("/",(request,response)=>{
    response.sendFile(path.join(__dirname,"pages/inicio.html"))
})

app.listen("9000",()=>{
    console.log("El servidor esta iniciado");
})

app.get("/listarProductos",(request,response)=>{
    cn.getAll(request,response);
    //response.end("Desplegando una salida"); //Despliega texto
    //response.json({nombre:"Christian"}); //Despliega json

})